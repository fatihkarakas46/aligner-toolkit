"use client"

import Home from "../page"

export default function SyntheticV0PageForDeployment() {
  return <Home />
}